import torch.nn as nn
import torch.nn.functional as F
from .contrast import Contrast
from .mp_encoder import Mp_encoder

class HeCo(nn.Module):
    """
    feat_drop
    attn_drop
    num_heads
    num_metapath
    """
    def __init__(self, hidden_dim, num_metapath, ori_feat_dim, feat_drop, attn_drop, tau, lam):
        super(HeCo, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_metapath = num_metapath
        self.fc_list = nn.ModuleList([nn.Linear(feats_dim, hidden_dim, bias=True)
                                      for feats_dim in ori_feat_dim])
        for fc in self.fc_list:
            nn.init.xavier_normal_(fc.weight, gain=1.5)

        # self.fs_list = nn.ModuleList([nn.Linear(1902, hidden_dim, bias=True)
        #                               for feats_dim in ori_feat_dim])
        # for fs in self.fs_list:
        #     nn.init.xavier_normal_(fs.weight, gain=1.5)
        if feat_drop > 0:
            self.feat_drop = nn.Dropout(feat_drop)
        else:
            self.feat_drop = lambda x: x

        self.sim = Mp_encoder(num_metapath, hidden_dim, attn_drop)
        self.ori = Mp_encoder(num_metapath, hidden_dim, attn_drop)
        self.contrast = Contrast(hidden_dim, tau, lam)

    def forward(self, sim_feature_list, ori_feature_list, pos, mps, sim_mps):  # p a s
        ori_h = []
        sim_h = []
        for i in range(len(sim_feature_list)):
            sim_h.append(F.elu(self.feat_drop(self.fc_list[i](sim_feature_list[i]))))
        for i in range(len(ori_feature_list)):
            ori_h.append(F.elu(self.feat_drop(self.fc_list[i](ori_feature_list[i]))))
        z_sim = self.sim(sim_h[0], sim_mps)
        z_ori = self.ori(ori_h[0], mps)
        loss = self.contrast(z_ori, z_sim, pos)
        return loss

    def get_embeds(self, feats, mps):
        z_mp = F.elu(self.fc_list[0](feats[0]))
        z_mp = self.ori(z_mp, mps)
        return z_mp.detach()

