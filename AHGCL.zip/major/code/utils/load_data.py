import numpy as np
import scipy.sparse as sp
import torch as th
from sklearn.preprocessing import OneHotEncoder


def encode_onehot(labels):
    labels = labels.reshape(-1, 1)
    enc = OneHotEncoder()
    enc.fit(labels)
    labels_onehot = enc.transform(labels).toarray()
    return labels_onehot


def preprocess_features(features):
    """Row-normalize feature matrix and convert to tuple representation"""
    rowsum = np.array(features.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    features = r_mat_inv.dot(features)
    return features.todense()


def normalize_adj(adj):
    """Symmetrically normalize adjacency matrix."""
    adj = sp.coo_matrix(adj)
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = th.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = th.from_numpy(sparse_mx.data)
    shape = th.Size(sparse_mx.shape)
    return th.sparse.FloatTensor(indices, values, shape)



def load_aminer(ratio, type_num):
    # The order of node types: 0 m 1 d 2 a 3 w
    path = "../data/AM/aminer/"
    sim_path = "../data/AM/sim_aminer/"
    label = np.load(path + "labels.npy").astype('int32')
    label = encode_onehot(label)
    meta_feature = sp.load_npz("../data/AM/p_f.npz").astype("float32")
    ori_feat_m = th.FloatTensor(preprocess_features(sp.eye(type_num[0])))
    sim_feat_m = th.FloatTensor(preprocess_features(sp.eye(type_num[0])+meta_feature))
    # sim_feat_m = th.FloatTensor(preprocess_features(sp.eye(type_num[0])))

    # Because none of M, D, A or W has features, we assign one-hot encodings to all of them.
    pap = sp.load_npz(path + "pap.npz")
    prp = sp.load_npz(path + "prp.npz")
    sim_pap = sp.load_npz(sim_path + "pap.npz")
    sim_prp = sp.load_npz(sim_path + "prp.npz")
    pos = sp.load_npz("../data/AM/merge_pos.npz")
    train = [np.load(path + "train_" + str(i) + ".npy") for i in ratio]
    test = [np.load(path + "test_" + str(i) + ".npy") for i in ratio]
    val = [np.load(path + "val_" + str(i) + ".npy") for i in ratio]

    label = th.FloatTensor(label)
    pap = sparse_mx_to_torch_sparse_tensor(normalize_adj(pap))
    prp = sparse_mx_to_torch_sparse_tensor(normalize_adj(prp))
    sim_pap = sparse_mx_to_torch_sparse_tensor(normalize_adj(sim_pap))
    sim_prp = sparse_mx_to_torch_sparse_tensor(normalize_adj(sim_prp))
    pos = sparse_mx_to_torch_sparse_tensor(pos)
    train = [th.LongTensor(i) for i in train]
    val = [th.LongTensor(i) for i in val]
    test = [th.LongTensor(i) for i in test]
    return ori_feat_m, sim_feat_m, [pap, prp], [sim_pap, sim_prp], pos, label, train, val, test


def load_data(dataset, ratio, type_num):

    data = load_aminer(ratio, type_num)
    return data