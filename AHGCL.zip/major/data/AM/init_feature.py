import scipy.sparse as sp
import numpy as np

fa = open(r'..\..\..\mp2vec\Aminer\Sim_embed\meta_data\result_pa.txt', 'r')
fa.readline()
feature_a = []
while True:
    x = fa.readline()
    if not x:
        break
    x = x.strip().split()
    if x[0][0] == 'p':
        list_e = [float(i) for i in x[1:]]
        feature_a.append(list_e)
feature_a = np.array(feature_a)
fa.close()
# print(feature_a.shape)

fr = open(r'..\..\..\mp2vec\Aminer\Sim_embed\meta_data\result_pr.txt', 'r')
fr.readline()
feature_r = []
while True:
    x = fr.readline()
    if not x:
        break
    x = x.strip().split()
    if x[0][0] == 'p':
        list_e = [float(i) for i in x[1:]]
        feature_r.append(list_e)
feature_r = np.array(feature_r)
fr.close()
# print(feature_r.shape)

feature = np.hstack((feature_a, feature_r))

feature_zero = np.zeros((6564, 6564-256))
feature = np.hstack((feature, feature_zero))
# print(feature)
# print(feature.shape)
feature = sp.coo_matrix(feature)
sp.save_npz("p_f.npz", feature)
