import scipy.sparse as sp
import numpy as np
path = 'aminer/'
sim = 'sim_aminer/'
pos = sp.load_npz(path + "pos.npz").toarray()
pos_sim = sp.load_npz(sim + "pos.npz").toarray()
print(type(pos))
merge = np.logical_or(pos,pos_sim)
merge = sp.coo_matrix(np.array(merge,dtype='int64'))
sp.save_npz("merge_pos.npz", merge)

