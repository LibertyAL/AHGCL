import numpy as np
import scipy.sparse as sp


####################################################
# This tool is to generate meta-path based adjacency
# matrix given original links.
####################################################


def generate_meta(dir_name, fname):
    pa = np.genfromtxt(dir_name + '/' + 'pa.txt')
    pr = np.genfromtxt(dir_name + '/' + 'pr.txt')

    A = 13329
    P = 6564
    R = 35890

    # np.ones(pa.shape[0]) 边数 pa[:, 0] paper pa[:, 1] author
    pa_ = sp.coo_matrix((np.ones(pa.shape[0]), (pa[:, 0], pa[:, 1])), shape=(P, A)).toarray()
    pr_ = sp.coo_matrix((np.ones(pr.shape[0]), (pr[:, 0], pr[:, 1])), shape=(P, R)).toarray()

    pap = np.matmul(pa_, pa_.T) > 0
    pap = sp.coo_matrix(pap)
    sp.save_npz('./' + dir_name + '/' + fname + 'ap.npz', pap)

    prp = np.matmul(pr_, pr_.T) > 0
    prp = sp.coo_matrix(prp)
    sp.save_npz('./' + dir_name + '/' + fname + 'rp.npz', prp)


if __name__ == '__main__':
    generate_meta('sim_aminer', 'p')